package com.tuan.samplesession34.config.security;

import com.tuan.samplesession34.entity.Account;
import com.tuan.samplesession34.exception.AccountNotFoundException;
import com.tuan.samplesession34.repository.AccountRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CustomAccountServiceDetail implements UserDetailsService {

    private final AccountRepository accountRepository;

    public CustomAccountServiceDetail(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<Account> account = accountRepository.findAccountByUsername(username);
        if (account.isPresent()) {
            return new CustomAccountDetail(account.get());
        } else {
            throw new AccountNotFoundException("Account not found");
        }
    }
}
