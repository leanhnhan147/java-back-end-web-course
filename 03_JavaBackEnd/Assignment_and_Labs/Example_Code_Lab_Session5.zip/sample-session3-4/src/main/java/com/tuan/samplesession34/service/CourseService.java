package com.tuan.samplesession34.service;

import com.tuan.samplesession34.dto.CourseDTO;

import java.util.List;

public interface CourseService extends BaseService<CourseDTO, Long>{

}
