package com.tuan.samplesession34.controller;

import com.tuan.samplesession34.dto.AuthRequest;
import com.tuan.samplesession34.util.JwtUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/authenticate")
public class AuthenticationController {

    private final AuthenticationManager authenticationManager;

    public AuthenticationController(AuthenticationManager authenticationManager) {
        this.authenticationManager = authenticationManager;
    }

    //Authenticate -> Generate JWT
    @PostMapping
    public ResponseEntity<String> generateToken(@RequestBody AuthRequest authRequest) {
        Authentication authentication =
                authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(
                      authRequest.getUsername(), authRequest.getPassword()
                ));
        if (authentication.isAuthenticated()) {
            return new ResponseEntity<>(JwtUtils.generateToken(authRequest.getUsername()), HttpStatus.OK);
        }
        return null;
    }
}
