package com.tuan.samplesession34.service;

import com.tuan.samplesession34.dto.CategoryDTO;

import java.util.List;

public interface CategoryService extends BaseService<CategoryDTO, Long> {
    void delete(List<CategoryDTO> categoryDTOS);
}
