package com.tuan.samplesession34.config.mapper;

import com.tuan.samplesession34.entity.Role;
import com.tuan.samplesession34.exception.RoleNotFoundExecption;
import com.tuan.samplesession34.repository.RoleRepository;
import org.modelmapper.AbstractConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

public class StringToRoleSetConverter extends AbstractConverter<Set<String>, Set<Role>> {

    @Autowired
    private RoleRepository roleRepository;

    @Transactional(readOnly = true)
    @Override
    protected Set<Role> convert(Set<String> strings) {
        Set<Role> roles = new HashSet<>();
        strings.forEach(role -> {
            Optional<Role> dbRole = roleRepository.findRoleByName(role);
            if (dbRole.isPresent()) {
                roles.add(dbRole.get());
            } else {
                throw new RoleNotFoundExecption("Role not found");
            }
        });
        return roles;
    }
}
