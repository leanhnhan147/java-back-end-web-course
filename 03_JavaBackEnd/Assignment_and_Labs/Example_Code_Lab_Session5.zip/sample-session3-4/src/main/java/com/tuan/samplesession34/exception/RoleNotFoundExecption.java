package com.tuan.samplesession34.exception;

import lombok.experimental.StandardException;

@StandardException
public class RoleNotFoundExecption extends RuntimeException{
}
