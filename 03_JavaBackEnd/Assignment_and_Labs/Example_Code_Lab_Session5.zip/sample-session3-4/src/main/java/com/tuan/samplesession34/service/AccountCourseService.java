package com.tuan.samplesession34.service;

import com.tuan.samplesession34.dto.RequestAccountCourseDTO;

import java.util.Set;

public interface AccountCourseService {
    void assign(Set<RequestAccountCourseDTO> accountDTO);
}
