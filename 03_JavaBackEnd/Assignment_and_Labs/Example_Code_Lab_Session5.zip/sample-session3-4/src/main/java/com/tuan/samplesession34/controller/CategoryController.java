package com.tuan.samplesession34.controller;

import com.tuan.samplesession34.constant.PaginationConstant;
import com.tuan.samplesession34.dto.CategoryDTO;
import com.tuan.samplesession34.dto.CourseDTO;
import com.tuan.samplesession34.service.CategoryService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/categories")
public class CategoryController {

    private final CategoryService categoryService;

    public CategoryController(CategoryService categoryService) {
        this.categoryService = categoryService;
    }

    @GetMapping
    public ResponseEntity<List<CategoryDTO>> getAll(
            @RequestParam(value = "pageNo", defaultValue = PaginationConstant.DEFAULT_PAGE_NUMBER, required = false) int pageNo,
            @RequestParam(value = "pageSize", defaultValue = PaginationConstant.DEFAULT_PAGE_SIZE, required = false) int pageSize,
            @RequestParam(value = "sortDir", defaultValue = PaginationConstant.DEFAULT_SORT_DIRECTION, required = false) String sortDir,
            @RequestParam(value = "sortBy", defaultValue = PaginationConstant.DEFAULT_SORT_BY, required = false) String sortBy
    ) {
        List<CategoryDTO> courseDTOS = categoryService.getAll(pageNo, pageSize, sortDir, sortBy);
        return new ResponseEntity<>(courseDTOS, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<CategoryDTO> getById(@PathVariable("id") Long id) {
        CategoryDTO categoryDTO = categoryService.getById(id);
        return new ResponseEntity<>(categoryDTO, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<CategoryDTO> create(@RequestBody CategoryDTO categoryDTO) {
        CategoryDTO result = categoryService.create(categoryDTO);
        return new ResponseEntity<>(result, HttpStatus.CREATED);
    }

    @PutMapping
    public ResponseEntity<CategoryDTO> update(@RequestBody CategoryDTO categoryDTO) {
        CategoryDTO result = categoryService.update(categoryDTO);
        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    @DeleteMapping
    public ResponseEntity<Void> delete(@RequestBody List<CategoryDTO> categoryDTOS) {
        categoryService.delete(categoryDTOS);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
