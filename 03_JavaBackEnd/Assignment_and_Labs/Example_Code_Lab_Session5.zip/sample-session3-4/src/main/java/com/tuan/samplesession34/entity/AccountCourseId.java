package com.tuan.samplesession34.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Embeddable
@AllArgsConstructor
@NoArgsConstructor
@Data
public class AccountCourseId implements Serializable {

    @Column(name = "account_id")
    private Long accountId;

    @Column(name = "course_id")
    private Long courseId;
}
