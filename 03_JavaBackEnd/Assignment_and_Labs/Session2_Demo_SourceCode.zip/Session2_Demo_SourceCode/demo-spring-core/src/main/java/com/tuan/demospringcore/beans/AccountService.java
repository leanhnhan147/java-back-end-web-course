package com.tuan.demospringcore.beans;

public interface AccountService {
    void showInfo();
}
