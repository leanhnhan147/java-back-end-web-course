package com.tuan.demospringcore.beans;

import org.springframework.stereotype.Service;

@Service
public class VIPAccountServiceImpl implements AccountService{
    @Override
    public void showInfo() {
        System.out.println("This is VIPAccountServiceImpl Bean");
    }
}
