package com.tuan.demospringcore.dependencyinjection;

import com.tuan.demospringcore.beans.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Before running:
 * Open comment: com/tuan/demospringcore/beans/BasicAccountServiceImpl.java:5
 * Open comment: com/tuan/demospringcore/beans/VIPAccountServiceImpl.java:5
 */
@RestController
@RequestMapping("/dependency-injection")
public class DependencyInjectionControllerDemo {

    //Field injection
//    @Autowired
//    @Qualifier("basicAccountServiceImpl")
    AccountService accountService;

    //Constructor injection - Recommend to use
    public DependencyInjectionControllerDemo(@Qualifier("basicAccountServiceImpl") AccountService accountService) {
        this.accountService = accountService;
    }

    @GetMapping("/demo")
    public void dependencyInjection() {
        accountService.showInfo();
    }

    //Method injection
//    @Autowired
//    private void setInjection(@Qualifier("basicAccountServiceImpl") AccountService accountService) {
//        this.accountService = accountService;
//    }
}
