package com.tuan.demospringcore.applicationcontext;

import com.tuan.demospringcore.beans.AccountService;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Open comment from BeanContainer.java class before performing demo on ApplicationContext
 */
@RestController
@RequestMapping("/application-context")
public class ApplicationContextControllerDemo {
    @Autowired
    private ApplicationContext applicationContext;

    /**
     * Call implementation (bean) by Interface class
     * If 2 beans implement from only one Interface, it will base on @Primary annotation to get which bean
     * @throws BeansException
     */
    //TODO before running: Open comment in com/tuan/demospringcore/configuration/BeanContainer.java:13
    @GetMapping("/firstDemo")
    public void callByUsingInterfaceClass() throws BeansException {
        AccountService accountService = applicationContext.getBean(AccountService.class);
        accountService.showInfo();
    }

    @GetMapping("/secondDemo")
    public void callByUsingBeanName() throws BeansException {
        AccountService accountService = (AccountService) applicationContext.getBean("basicAccountService");
        accountService.showInfo();
    }

    /**
     * See what differences between scope singleton and prototype
     */
    //TODO before running: Open comment in com/tuan/demospringcore/configuration/BeanContainer.java:16
    @GetMapping("/thirdDemo")
    public void differenceScopeType() {
        AccountService firstAccountService = (AccountService) applicationContext.getBean("basicAccountService");
        AccountService secondAccountService = (AccountService) applicationContext.getBean("basicAccountService");
        if (firstAccountService.equals(secondAccountService)) {
            System.out.println("Same instance");
        } else {
            System.out.println("Different instance");
        }
    }
}
