package com.tuan.demospringcore.beans;

import org.springframework.stereotype.Service;

@Service
public class BasicAccountServiceImpl implements AccountService{
    @Override
    public void showInfo() {
        System.out.println("This is BasicAccountServiceImpl Bean");
    }
}
