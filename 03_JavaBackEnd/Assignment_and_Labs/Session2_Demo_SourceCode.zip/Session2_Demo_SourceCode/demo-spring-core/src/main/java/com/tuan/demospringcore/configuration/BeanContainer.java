//package com.tuan.demospringcore.configuration;
//
//import com.tuan.demospringcore.beans.AccountService;
//import com.tuan.demospringcore.beans.BasicAccountServiceImpl;
//import com.tuan.demospringcore.beans.VIPAccountServiceImpl;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.Primary;
//import org.springframework.context.annotation.Scope;
//
//@Configuration
//public class BeanContainer {
//    @Bean
////    @Primary
////    @Scope(scopeName = "singleton")
////    @Scope(scopeName = "prototype")
//    public AccountService basicAccountService() {
//        return new BasicAccountServiceImpl();
//    }
//
//    @Bean
//    public AccountService VIPAccountService() {
//        return new VIPAccountServiceImpl();
//    }
//}
