package com.tuan.demorestfulwebservice.controller;

import com.tuan.demorestfulwebservice.model.User;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

//Restful API with CRUD operations
@RestController
@RequestMapping("/users")
public class UserController {

    private static final Map<Long, User> userMap = new HashMap<>();

    static {
        userMap.put(1L, new User(1L, "Viet", LocalDate.of(2000, 5, 12)));
        userMap.put(2L, new User(2L, "Duy", LocalDate.of(2002, 7, 12)));
    }

    @GetMapping
    public ResponseEntity<List<User>> getAllUsers() {
        //Stream API in Java 8
        List<User> users = userMap.values().stream().collect(Collectors.toList());
        if (users.isEmpty()) {
            return new ResponseEntity<>(Collections.emptyList(), HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(users, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        User user = userMap.get(id);
        if (user == null) {
            return new ResponseEntity<>((User) null, HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(user, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<User> createNewUser(@RequestBody User user) {
        User existedUser = userMap.get(user.getId());
        if (existedUser == null) {
            userMap.put(user.getId(), user);
            return new ResponseEntity<>(user, HttpStatus.CREATED);
        }
        return new ResponseEntity<>((User) null, HttpStatus.BAD_REQUEST);
    }

    @PutMapping
    public ResponseEntity<User> updateUser(@RequestBody User user) {
        User existedUser = userMap.get(user.getId());
        if (existedUser != null) {
            userMap.replace(user.getId(), user);
            return new ResponseEntity<>(user, HttpStatus.OK);
        }
        return new ResponseEntity<>((User) null, HttpStatus.BAD_REQUEST);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<User> deleteUser(@PathVariable Long id) {
        User existedUser = userMap.get(id);
        if (existedUser != null) {
            userMap.remove(id);
            return new ResponseEntity<>(existedUser, HttpStatus.OK);
        }
        return new ResponseEntity<>((User) null, HttpStatus.BAD_REQUEST);
    }

}
