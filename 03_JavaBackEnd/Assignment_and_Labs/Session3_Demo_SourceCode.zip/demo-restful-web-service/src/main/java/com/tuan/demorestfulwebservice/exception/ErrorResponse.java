package com.tuan.demorestfulwebservice.exception;

import java.time.ZonedDateTime;

public class ErrorResponse {
    private int statusCode;
    private ZonedDateTime timestamp;
    private String message;

    public ErrorResponse(int statusCode, ZonedDateTime timestamp, String message) {
        this.statusCode = statusCode;
        this.timestamp = timestamp;
        this.message = message;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public ZonedDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(ZonedDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
