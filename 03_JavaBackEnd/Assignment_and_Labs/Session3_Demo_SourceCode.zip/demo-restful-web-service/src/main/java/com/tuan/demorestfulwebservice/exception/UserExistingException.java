package com.tuan.demorestfulwebservice.exception;

public class UserExistingException extends RuntimeException{

    public UserExistingException(String message) {
        super(message);
    }
}
