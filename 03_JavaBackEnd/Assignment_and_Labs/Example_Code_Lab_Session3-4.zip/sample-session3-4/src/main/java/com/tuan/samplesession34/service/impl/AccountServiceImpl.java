package com.tuan.samplesession34.service.impl;

import com.tuan.samplesession34.dto.AccountDTO;
import com.tuan.samplesession34.entity.Account;
import com.tuan.samplesession34.exception.AccountNotFoundException;
import com.tuan.samplesession34.repository.AccountRepository;
import com.tuan.samplesession34.service.AccountService;
import com.tuan.samplesession34.util.BcryptUtils;
import com.tuan.samplesession34.util.PaginationSortingUtils;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.lang.reflect.Type;
import java.time.ZonedDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;
    private final ModelMapper modelMapper;

    public AccountServiceImpl(AccountRepository accountRepository, ModelMapper modelMapper) {
        this.accountRepository = accountRepository;
        this.modelMapper = modelMapper;
    }

    @Transactional(readOnly = true)
    @Override
    public AccountDTO getById(Long id) {
        Optional<Account> account = accountRepository.findById(id);
        if (account.isPresent()) {
            return modelMapper.map(account, AccountDTO.class);
        } else {
            throw new AccountNotFoundException("Account not found");
        }
    }

    @Transactional(readOnly = true)
    @Override
    public List<AccountDTO> getAll(int pageNo, int pageSize, String sortDir, String sortBy) {
        Pageable pageable = PaginationSortingUtils.getPageable(pageNo, pageSize, sortDir, sortBy);
        List<Account> accounts = accountRepository.findAll(pageable).getContent();
        if (!accounts.isEmpty()) {
            Type listType = new TypeToken<List<AccountDTO>>() {}.getType();
            return modelMapper.map(accounts, listType);
        } else {
            return Collections.emptyList();
        }
    }

    @Transactional
    @Override
    public AccountDTO create(AccountDTO accountDTO) {
        preCreate(accountDTO);
        Account account = modelMapper.map(accountDTO, Account.class);
        accountRepository.save(account);
        return accountDTO;
    }

    @Transactional
    @Override
    public AccountDTO update(AccountDTO accountDTO) {
        Optional<Account> existedAccount = accountRepository.findById(accountDTO.getId());
        if (existedAccount.isPresent()) {
            preUpdate(accountDTO, existedAccount.get());
            accountRepository.save(existedAccount.get());
            return accountDTO;
        } else {
            throw new AccountNotFoundException("Account not found");
        }
    }

    @Transactional
    @Override
    public void delete(Long id) {
        Optional<Account> existedAccount = accountRepository.findById(id);
        if (existedAccount.isPresent()) {
            accountRepository.deleteById(id);
        } else {
            throw new AccountNotFoundException("Account not found");
        }
    }

    @Transactional
    @Override
    public AccountDTO changeStatus(Boolean isEnable, Long id) {
        int result = accountRepository.updateStatus(isEnable, id);
        if (result > 0) {
            Optional<Account> account = accountRepository.findById(id);
            return modelMapper.map(account, AccountDTO.class);
        }
        return null;
    }

    private void preUpdate(AccountDTO accountDTO, Account account) {
        if (!BcryptUtils.check(accountDTO.getPassword(), account.getPassword())) {
            account.setPassword(BcryptUtils.encode(accountDTO.getPassword()));
        }
        account.getUser().setFirstName(accountDTO.getFirstName());
        account.getUser().setLastName(accountDTO.getLastName());
        account.getUser().setEmail(accountDTO.getEmail());
    }
    private void preCreate(AccountDTO accountDTO) {
        accountDTO.setId(null);
        accountDTO.setCreatedDate(ZonedDateTime.now());
        accountDTO.setPassword(BcryptUtils.encode(accountDTO.getPassword()));
    }

}
