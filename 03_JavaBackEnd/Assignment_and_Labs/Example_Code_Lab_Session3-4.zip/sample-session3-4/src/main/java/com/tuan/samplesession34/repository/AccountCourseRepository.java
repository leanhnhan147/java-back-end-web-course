package com.tuan.samplesession34.repository;

import com.tuan.samplesession34.entity.AccountCourse;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AccountCourseRepository extends JpaRepository<AccountCourse, Long> {
}
