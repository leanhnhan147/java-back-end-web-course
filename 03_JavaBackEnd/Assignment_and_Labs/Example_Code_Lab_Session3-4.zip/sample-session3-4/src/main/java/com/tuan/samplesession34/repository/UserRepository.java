package com.tuan.samplesession34.repository;

import com.tuan.samplesession34.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
}
