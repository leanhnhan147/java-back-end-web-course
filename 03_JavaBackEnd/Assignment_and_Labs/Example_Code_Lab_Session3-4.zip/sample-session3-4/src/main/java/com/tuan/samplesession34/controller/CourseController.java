package com.tuan.samplesession34.controller;

import com.tuan.samplesession34.constant.PaginationConstant;
import com.tuan.samplesession34.dto.CategoryDTO;
import com.tuan.samplesession34.dto.CourseDTO;
import com.tuan.samplesession34.entity.Course;
import com.tuan.samplesession34.service.CourseService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/courses")
public class CourseController {
    private final CourseService courseService;


    public CourseController(CourseService courseService) {
        this.courseService = courseService;
    }

    @GetMapping
    public ResponseEntity<List<CourseDTO>> getAll(
            @RequestParam(value = "pageNo", defaultValue = PaginationConstant.DEFAULT_PAGE_NUMBER, required = false) int pageNo,
            @RequestParam(value = "pageSize", defaultValue = PaginationConstant.DEFAULT_PAGE_SIZE, required = false) int pageSize,
            @RequestParam(value = "sortDir", defaultValue = PaginationConstant.DEFAULT_SORT_DIRECTION, required = false) String sortDir,
            @RequestParam(value = "sortBy", defaultValue = PaginationConstant.DEFAULT_SORT_BY, required = false) String sortBy
    ) {
        List<CourseDTO> courseDTOS = courseService.getAll(pageNo, pageSize, sortDir, sortBy);
        return new ResponseEntity<>(courseDTOS, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<CourseDTO> getById(@PathVariable("id") Long id) {
        CourseDTO courseDTO = courseService.getById(id);
        return new ResponseEntity<>(courseDTO, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<CourseDTO> create(@RequestBody CourseDTO courseDTO) {
        CourseDTO result = courseService.create(courseDTO);
        return new ResponseEntity<>(result, HttpStatus.CREATED);
    }

    @PutMapping
    public ResponseEntity<CourseDTO> update(@RequestBody CourseDTO courseDTO) {
        CourseDTO result = courseService.update(courseDTO);
        return new ResponseEntity<>(result, HttpStatus.OK);
    }
}
