package com.tuan.samplesession34.service.impl;

import com.tuan.samplesession34.dto.CourseDTO;
import com.tuan.samplesession34.entity.Category;
import com.tuan.samplesession34.entity.Course;
import com.tuan.samplesession34.exception.CourseNotFoundException;
import com.tuan.samplesession34.repository.CategoryRepository;
import com.tuan.samplesession34.repository.CourseRepository;
import com.tuan.samplesession34.service.CourseService;
import com.tuan.samplesession34.util.PaginationSortingUtils;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.lang.reflect.Type;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class CourseServiceImpl implements CourseService {

    private final CourseRepository courseRepository;
    private final ModelMapper modelMapper;
    private final CategoryRepository categoryRepository;

    public CourseServiceImpl(CourseRepository courseRepository, ModelMapper modelMapper, CategoryRepository categoryRepository) {
        this.courseRepository = courseRepository;
        this.modelMapper = modelMapper;
        this.categoryRepository = categoryRepository;
    }

    @Transactional(readOnly = true)
    @Override
    public CourseDTO getById(Long id) {
        Optional<Course> course = courseRepository.findById(id);
        if (course.isPresent()) {
            return modelMapper.map(course, CourseDTO.class);
        } else {
            throw new CourseNotFoundException("Not found Course");
        }
    }

    @Override
    public List<CourseDTO> getAll(int pageNo, int pageSize, String sortDir, String sortBy) {
        Pageable pageable = PaginationSortingUtils.getPageable(pageNo, pageSize, sortDir, sortBy);
        List<Course> courses = courseRepository.findAll(pageable).getContent();
        if (!courses.isEmpty()) {
            Type listType = new TypeToken<List<CourseDTO>>() {}.getType();
            return modelMapper.map(courses, listType);
        } else {
            return Collections.emptyList();
        }
    }

    @Transactional
    @Override
    public CourseDTO create(CourseDTO courseDTO) {
        courseDTO.setId(null);
        Course course = modelMapper.map(courseDTO, Course.class);
        Optional<Category> existedCategory = categoryRepository.findByName(courseDTO.getCategory());
        if (existedCategory.isEmpty()) {
            Category newCategory = new Category();
            newCategory.setName(courseDTO.getCategory());
            course.setCategory(newCategory);
        } else {
            course.setCategory(existedCategory.get());
        }
        courseRepository.save(course);
        return courseDTO;
    }

    //TODO: handle this
    @Override
    public CourseDTO update(CourseDTO courseDTO) {
        return null;
    }
}
