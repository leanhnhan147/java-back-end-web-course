package com.tuan.samplesession34.controller;

import com.tuan.samplesession34.dto.RequestAccountCourseDTO;
import com.tuan.samplesession34.service.AccountCourseService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Set;

@RestController
@RequestMapping("/assignments")
public class AccountCourseController {
    private final AccountCourseService accountCourseService;

    public AccountCourseController(AccountCourseService accountCourseService) {
        this.accountCourseService = accountCourseService;
    }

    @PostMapping
    public ResponseEntity<Void> assign(@RequestBody Set<RequestAccountCourseDTO> accountCourses) {
        accountCourseService.assign(accountCourses);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
