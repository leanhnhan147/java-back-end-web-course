package com.tuan.samplesession34.service.impl;

import com.tuan.samplesession34.dto.RequestAccountCourseDTO;
import com.tuan.samplesession34.entity.Account;
import com.tuan.samplesession34.entity.AccountCourse;
import com.tuan.samplesession34.entity.AccountCourseId;
import com.tuan.samplesession34.entity.Course;
import com.tuan.samplesession34.repository.AccountCourseRepository;
import com.tuan.samplesession34.repository.AccountRepository;
import com.tuan.samplesession34.repository.CourseRepository;
import com.tuan.samplesession34.service.AccountCourseService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

@Service
public class AccountCourseServiceImpl implements AccountCourseService {

    private final AccountCourseRepository accountCourseRepository;

    private final AccountRepository accountRepository;

    private final CourseRepository courseRepository;

    public AccountCourseServiceImpl(AccountCourseRepository accountCourseRepository, AccountRepository accountRepository, CourseRepository courseRepository) {
        this.accountCourseRepository = accountCourseRepository;
        this.accountRepository = accountRepository;
        this.courseRepository = courseRepository;
    }

    @Transactional
    @Override
    public void assign(Set<RequestAccountCourseDTO> accountDTO) {
        Set<AccountCourse> accountCourses = new HashSet<>();
        for (RequestAccountCourseDTO requestAccountCourseDTO : accountDTO) {
            Optional<Account> account = accountRepository.findById(requestAccountCourseDTO.getAccountId());
            if (account.isPresent() && account.get().getStatus()) {
                for (Long id : requestAccountCourseDTO.getCourseIds()) {
                    Optional<Course> course = courseRepository.findById(id);
                    if (course.isPresent()) {
                        AccountCourse accountCourse = new AccountCourse();
                        accountCourse.setAccount(account.get());
                        accountCourse.setCourse(course.get());
                        //
                        AccountCourseId accountCourseId = new AccountCourseId();
                        accountCourseId.setAccountId(requestAccountCourseDTO.getAccountId());
                        accountCourseId.setCourseId(id);
                        accountCourse.setAccountCourseId(accountCourseId);
                        //
                        accountCourses.add(accountCourse);
                    }
                }
            } else {
                break;
            }
        }
        accountCourseRepository.saveAll(accountCourses);
    }
}
