package com.tuan.samplesession34;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleSession34Application {

    public static void main(String[] args) {
        SpringApplication.run(SampleSession34Application.class, args);
    }

}
