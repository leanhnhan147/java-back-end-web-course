package com.tuan.samplesession34.service.impl;

import com.tuan.samplesession34.dto.CategoryDTO;
import com.tuan.samplesession34.dto.CourseDTO;
import com.tuan.samplesession34.entity.Category;
import com.tuan.samplesession34.exception.CategoryNotFoundException;
import com.tuan.samplesession34.repository.CategoryRepository;
import com.tuan.samplesession34.service.CategoryService;
import com.tuan.samplesession34.util.PaginationSortingUtils;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.lang.reflect.Type;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class CategoryServiceImpl implements CategoryService {

    private final CategoryRepository categoryRepository;
    private final ModelMapper modelMapper;

    public CategoryServiceImpl(CategoryRepository categoryRepository, ModelMapper modelMapper) {
        this.categoryRepository = categoryRepository;
        this.modelMapper = modelMapper;
    }

    @Transactional(readOnly = true)
    @Override
    public CategoryDTO getById(Long key) {
        Optional<Category> category = categoryRepository.findById(key);
        if (category.isPresent()) {
            return modelMapper.map(category, CategoryDTO.class);
        } else {
            throw new CategoryNotFoundException("Not found category");
        }
    }

    @Transactional(readOnly = true)
    @Override
    public List<CategoryDTO> getAll(int pageNo, int pageSize, String sortDir, String sortBy) {
        Pageable pageable = PaginationSortingUtils.getPageable(pageNo, pageSize, sortDir, sortBy);
        List<Category> categories = categoryRepository.findAll(pageable).getContent();
        if (!categories.isEmpty()) {
            Type listType = new TypeToken<List<CategoryDTO>>() {}.getType();
            return modelMapper.map(categories, listType);
        } else {
            return Collections.emptyList();
        }
    }

    @Transactional
    @Override
    public CategoryDTO create(CategoryDTO type) {
        type.setId(null);
        Category category = modelMapper.map(type, Category.class);
        categoryRepository.save(category);
        return type;
    }

    @Transactional
    @Override
    public CategoryDTO update(CategoryDTO type) {
        Optional<Category> existedCategory = categoryRepository.findById(type.getId());
        if (existedCategory.isPresent()) {
            Category category = modelMapper.map(type, Category.class);
            categoryRepository.save(category);
            return type;
        } else {
            throw new CategoryNotFoundException("Not found category");
        }
    }

    @Transactional
    @Override
    public void delete(List<CategoryDTO> categoryDTOS) {
        Type listType = new TypeToken<List<CourseDTO>>() {}.getType();
        List<Category> categories = modelMapper.map(categoryDTOS, listType);
        categoryRepository.deleteAll(categories);
    }
}
