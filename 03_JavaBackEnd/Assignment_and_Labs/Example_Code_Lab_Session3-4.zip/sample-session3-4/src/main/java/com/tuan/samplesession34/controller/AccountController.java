package com.tuan.samplesession34.controller;

import com.tuan.samplesession34.constant.PaginationConstant;
import com.tuan.samplesession34.dto.AccountDTO;
import com.tuan.samplesession34.service.AccountService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/accounts")
public class AccountController {

    private final AccountService accountService;

    public AccountController(AccountService accountService) {
        this.accountService = accountService;
    }

    @GetMapping("/{id}")
    public ResponseEntity<AccountDTO> getById(@PathVariable("id") Long id) {
        AccountDTO accountDTO = accountService.getById(id);
        return new ResponseEntity<>(accountDTO, HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<AccountDTO>> getAll(
            @RequestParam(value = "pageNo", defaultValue = PaginationConstant.DEFAULT_PAGE_NUMBER, required = false) int pageNo,
            @RequestParam(value = "pageSize", defaultValue = PaginationConstant.DEFAULT_PAGE_SIZE, required = false) int pageSize,
            @RequestParam(value = "sortDir", defaultValue = PaginationConstant.DEFAULT_SORT_DIRECTION, required = false) String sortDir,
            @RequestParam(value = "sortBy", defaultValue = PaginationConstant.DEFAULT_SORT_BY, required = false) String sortBy
    ) {
        List<AccountDTO> accountDTOS = accountService.getAll(pageNo, pageSize, sortDir, sortBy);
        return new ResponseEntity<>(accountDTOS, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<AccountDTO> create(@RequestBody AccountDTO accountDTO) {
        AccountDTO savedAccount = accountService.create(accountDTO);
        return new ResponseEntity<>(savedAccount, HttpStatus.CREATED);
    }

    @PutMapping
    public ResponseEntity<AccountDTO> update(@RequestBody AccountDTO accountDTO) {
        AccountDTO savedAccount = accountService.update(accountDTO);
        return new ResponseEntity<>(savedAccount, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") Long id) {
        accountService.delete(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PutMapping("/{id}/status/{isEnable}")
    public ResponseEntity<AccountDTO> changeStatus(
            @PathVariable("id") Long id, @PathVariable("isEnable") Boolean isEnable) {
        AccountDTO accountDTO = accountService.changeStatus(isEnable, id);
        return new ResponseEntity<>(accountDTO, HttpStatus.OK);
    }
}
