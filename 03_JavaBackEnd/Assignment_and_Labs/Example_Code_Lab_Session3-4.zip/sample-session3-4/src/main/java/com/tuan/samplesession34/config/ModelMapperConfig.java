package com.tuan.samplesession34.config;

import com.tuan.samplesession34.dto.AccountDTO;
import com.tuan.samplesession34.dto.CategoryDTO;
import com.tuan.samplesession34.dto.CourseDTO;
import com.tuan.samplesession34.entity.Account;
import com.tuan.samplesession34.entity.Course;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.NamingConventions;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ModelMapperConfig {
    @Bean
    public ModelMapper modelMapper() {
        ModelMapper modelMapper = new ModelMapper();
        modelMapper.getConfiguration()
                .setSourceNamingConvention(NamingConventions.NONE)
                .setDestinationNamingConvention(NamingConventions.NONE);
        //map entity to dto
        modelMapper.createTypeMap(Account.class, AccountDTO.class)
                .addMapping(src -> src.getUser().getFirstName(), AccountDTO::setFirstName)
                .addMapping(src -> src.getUser().getLastName(), AccountDTO::setLastName)
                .addMapping(src -> src.getUser().getEmail(), AccountDTO::setEmail);

        modelMapper.createTypeMap(Course.class, CourseDTO.class)
                        .addMapping(src -> src.getCategory().getName(), CourseDTO::setCategory);
        //map dto to entity
        modelMapper.createTypeMap(AccountDTO.class, Account.class)
                .addMapping(AccountDTO::getFirstName, (dest, value) -> dest.getUser().setFirstName(value != null ? value.toString() : null))
                .addMapping(AccountDTO::getLastName, (dest, value) -> dest.getUser().setLastName(value != null ? value.toString() : null))
                .addMapping(AccountDTO::getEmail, (dest, value) -> dest.getUser().setEmail(value != null ? value.toString() : null));

        modelMapper.createTypeMap(CourseDTO.class, Course.class)
                .addMapping(CourseDTO::getCategory, (dest, value) -> dest.getCategory().setName(value != null ? value.toString() : null));
        return modelMapper;
    }
}
