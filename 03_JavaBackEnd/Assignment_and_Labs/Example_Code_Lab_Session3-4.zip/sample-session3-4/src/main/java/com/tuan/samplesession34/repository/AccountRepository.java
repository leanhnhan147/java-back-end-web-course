package com.tuan.samplesession34.repository;

import com.tuan.samplesession34.entity.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

public interface AccountRepository extends JpaRepository<Account, Long> {

    @Modifying
    @Query("update Account a set a.status = :status where a.id = :id")
    int updateStatus(Boolean status, Long id);
}
