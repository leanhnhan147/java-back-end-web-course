package com.tuan.samplesession34.dto;

import lombok.Data;

import java.util.Set;

@Data
public class RequestAccountCourseDTO {
    private Long accountId;
    private Set<Long> courseIds;
}
