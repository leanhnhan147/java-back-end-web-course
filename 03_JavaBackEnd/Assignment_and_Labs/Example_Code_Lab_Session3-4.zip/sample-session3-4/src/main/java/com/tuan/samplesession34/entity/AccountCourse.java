package com.tuan.samplesession34.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.ZonedDateTime;

@Entity
@Table(name = "account_course")
@AllArgsConstructor
@NoArgsConstructor
@Data
public class AccountCourse {
    @EmbeddedId
    private AccountCourseId accountCourseId;

    @Column(name = "registration_date")
    private ZonedDateTime registrationDate;

    @Column(name = "purchase_price")
    private Double purchasePrice;

    @ManyToOne
    @MapsId("accountId")
    private Account account;

    @EqualsAndHashCode.Exclude
    @ManyToOne
    @MapsId("courseId")
    private Course course;
}
