package com.tuan.samplesession34;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampleSession34ApplicationTests {

    @Test
    void contextLoads() {
    }

}
