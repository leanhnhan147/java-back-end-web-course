package com.tuan.demorestfulwebservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoRestfulWebServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
