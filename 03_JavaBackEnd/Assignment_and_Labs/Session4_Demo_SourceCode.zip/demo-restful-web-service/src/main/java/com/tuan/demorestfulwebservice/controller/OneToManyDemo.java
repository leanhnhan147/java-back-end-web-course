package com.tuan.demorestfulwebservice.controller;

import com.tuan.demorestfulwebservice.model.Instructor;
import com.tuan.demorestfulwebservice.model.User;
import com.tuan.demorestfulwebservice.repository.IdentificationRepository;
import com.tuan.demorestfulwebservice.repository.InstructorRepository;
import com.tuan.demorestfulwebservice.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/onetomany")
public class OneToManyDemo {
    @Autowired
    private InstructorRepository instructorRepository;

    @GetMapping("/{id}")
    public Instructor getUserById(@PathVariable("id") Long id) {
        Optional<Instructor> instructor = instructorRepository.findById(id);
        return instructor.get();
    }

    @PostMapping
    public Instructor insertUser(@RequestBody Instructor instructor) {
        instructor.getCourses().stream().forEach(c -> {
            c.setInstructor(instructor);
        });
        return instructorRepository.save(instructor);
    }

}
