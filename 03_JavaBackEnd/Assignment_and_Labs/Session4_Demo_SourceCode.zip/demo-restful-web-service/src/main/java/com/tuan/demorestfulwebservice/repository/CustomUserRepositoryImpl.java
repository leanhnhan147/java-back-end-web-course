package com.tuan.demorestfulwebservice.repository;

import com.tuan.demorestfulwebservice.model.User;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;

import java.util.List;

public class CustomUserRepositoryImpl implements CustomUserRepository{
    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<User> findUserByNameUsingCriteria(String name) {
        EntityManagerFactory entityManagerFactory
                = entityManager.getEntityManagerFactory();
        CriteriaBuilder criteriaBuilder =
                entityManagerFactory.getCriteriaBuilder();
        CriteriaQuery<User> criteriaQuery = criteriaBuilder.createQuery(User.class);
        Root<User> userRoot = criteriaQuery.from(User.class); //from user
        criteriaQuery.select(userRoot).where(criteriaBuilder.equal(userRoot.get("name"), name));
        // where name = :name
        TypedQuery<User> typedQuery = entityManager.createQuery(criteriaQuery);
        return typedQuery.getResultList();
    }
}
