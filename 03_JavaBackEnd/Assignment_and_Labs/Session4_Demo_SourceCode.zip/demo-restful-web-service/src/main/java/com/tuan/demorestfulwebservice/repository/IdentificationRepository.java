package com.tuan.demorestfulwebservice.repository;

import com.tuan.demorestfulwebservice.model.Identification;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IdentificationRepository extends JpaRepository<Identification, Long> {
}
