package com.tuan.demorestfulwebservice.controller;

import com.tuan.demorestfulwebservice.dto.UserDTO;
import com.tuan.demorestfulwebservice.model.User;
import com.tuan.demorestfulwebservice.repository.IdentificationRepository;
import com.tuan.demorestfulwebservice.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("onetoone")
public class OneToOneDemo {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private IdentificationRepository identificationRepository;

    @GetMapping("/{id}")
    public User getUserById(@PathVariable("id") Long id) {
        Optional<User> user = userRepository.findById(id);
        return user.get();
    }

    @PostMapping
    public User insertUser(@RequestBody User user) {
        return userRepository.save(user);
    }

//    @DeleteMapping("/{id}")
//    public void delete(@PathVariable("id") Long id) {
//        userRepository.deleteById(id);
//    }
}
