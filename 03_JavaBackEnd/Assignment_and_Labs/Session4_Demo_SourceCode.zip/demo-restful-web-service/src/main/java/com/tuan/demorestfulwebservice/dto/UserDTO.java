package com.tuan.demorestfulwebservice.dto;

public class UserDTO {
    private Long id;
    private String name;
    ///
    private String nameIdentification;
    private String dateOfExpiry;

    //getter/setters
}
