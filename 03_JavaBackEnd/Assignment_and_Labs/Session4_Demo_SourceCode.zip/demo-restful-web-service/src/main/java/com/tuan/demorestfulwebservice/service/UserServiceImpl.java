package com.tuan.demorestfulwebservice.service;

import com.tuan.demorestfulwebservice.exception.UserExistingException;
import com.tuan.demorestfulwebservice.exception.UserNotFoundException;
import com.tuan.demorestfulwebservice.model.User;
import com.tuan.demorestfulwebservice.repository.UserRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public Optional<User> findById(Long id) {
        return userRepository.findById(id);
    }

    @Transactional
    @Override
    public User update(User user) {
        if (user.getId() != null) {
            Optional<User> existedUser = userRepository.findById(user.getId());
            if (existedUser.isPresent()) {
                return userRepository.save(user);
            }
        }
        throw new UserNotFoundException("Not found user");
    }

    @Transactional
    @Override
    public User insert(User user) {
        if (user.getId() != null) {
            Optional<User> existedUser = userRepository.findById(user.getId());
            if (existedUser.isPresent()) {
                throw new UserExistingException("User is existing");
            }
        }
        return userRepository.save(user);
    }

    @Transactional
    @Override
    public void delete(Long id) {
        Optional<User> existedUser = userRepository.findById(id);
        if (existedUser.isPresent()) {
            userRepository.deleteById(id);
        } else {
            throw new UserNotFoundException("User not found");
        }
    }

    @Transactional(readOnly = true)
    @Override
    public List<User> findAll(int pageNum, int pageSize, String sortDir, String sortBy) {
        PageRequest pageRequest = getPageRequest(pageNum, pageSize, sortDir, sortBy);
        Page<User> pageUser = userRepository.findAll(pageRequest);
        return pageUser.getContent();
    }

    @Transactional(readOnly = true)
    @Override
    public List<User> findAllByName(int pageNum, int pageSize, String sortDir, String sortBy, String filterBy) {
        PageRequest pageRequest = getPageRequest(pageNum, pageSize, sortDir, sortBy);
        return userRepository.findAllByNameIsContaining(filterBy, pageRequest);
    }

    private PageRequest getPageRequest(int pageNum, int pageSize, String sortDir, String sortBy) {
        Sort sort = sortDir.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortBy).ascending()
                : Sort.by(sortBy).descending();
        PageRequest pageRequest = PageRequest.of(pageNum, pageSize, sort);
        return pageRequest;
    }
}
