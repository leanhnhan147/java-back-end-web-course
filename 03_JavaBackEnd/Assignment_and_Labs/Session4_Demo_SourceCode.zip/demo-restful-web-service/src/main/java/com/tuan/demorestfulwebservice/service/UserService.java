package com.tuan.demorestfulwebservice.service;

import com.tuan.demorestfulwebservice.model.User;

import java.util.List;
import java.util.Optional;

public interface UserService {
    Optional<User> findById(Long id);
    User update(User user);
    User insert(User user);
    void delete(Long id);
    List<User> findAll(int pageNum, int pageSize, String sortDir, String sortBy);
    List<User> findAllByName(int pageNum, int pageSize, String sortDir, String sortBy, String filterBy);
}
