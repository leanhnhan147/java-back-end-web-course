package com.tuan.demorestfulwebservice.controller;

import com.tuan.demorestfulwebservice.model.User;
import com.tuan.demorestfulwebservice.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

//Restful API with CRUD operations
@RestController
@RequestMapping("/users")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping
    public ResponseEntity<List<User>> getAll(
            @RequestParam("pageNum") int pageNum,
            @RequestParam("pageSize") int pageSize,
            @RequestParam("sortDir") String sortDir,
            @RequestParam("sortBy") String sortBy,
            @RequestParam(value = "filterByName", required = false) String filterByName
    ) {
        List<User> users;
        if (filterByName == null || filterByName.trim().isEmpty() || filterByName.trim().isBlank()) {
            users = userService.findAll(pageNum, pageSize, sortDir, sortBy);
        } else {
            users = userService.findAllByName(pageNum, pageSize, sortDir, sortBy, filterByName);
        }
        if (users.isEmpty()) {
            return new ResponseEntity<>(Collections.emptyList(), HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(users, HttpStatus.OK);
    }

    @GetMapping("/pageAndSortAndFilter")
    public List<User> getAllBy(
            @RequestParam("pageNum") int pageNum,
            @RequestParam("pageSize") int pageSize,
            @RequestParam("sortDir") String sortDir,
            @RequestParam("sortBy") String sortBy,
            @RequestParam("filterBy") String filterBy
    ) {
        return userService.findAllByName(pageNum, pageSize, sortDir, sortBy, filterBy);
    }

    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        Optional<User> user = userService.findById(id);
        if (user.isEmpty()) {
            return new ResponseEntity<>((User) null, HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(user.get(), HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<User> createNewUser(@RequestBody User user) {
        User existedUser = userService.insert(user);
        return new ResponseEntity<>(existedUser, HttpStatus.CREATED);
    }

    @PutMapping
    public ResponseEntity<User> updateUser(@RequestBody User user) {
        User existedUser = userService.update(user);
        return new ResponseEntity<>(existedUser, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<User> deleteUser(@PathVariable Long id) {
        userService.delete(id);
        return new ResponseEntity<>((User) null, HttpStatus.OK);
    }

}
