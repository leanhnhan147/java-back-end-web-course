package com.tuan.demorestfulwebservice.repository;

import com.mysql.cj.log.Log;
import com.tuan.demorestfulwebservice.model.Course;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseRespository extends JpaRepository<Course, Long> {
}
