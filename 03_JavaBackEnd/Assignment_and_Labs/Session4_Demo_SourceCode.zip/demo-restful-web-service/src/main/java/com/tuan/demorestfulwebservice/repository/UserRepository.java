package com.tuan.demorestfulwebservice.repository;

import com.tuan.demorestfulwebservice.model.User;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRepository extends JpaRepository<User, Long>, CustomUserRepository {
    List<User> findAllByNameIsContaining(String filterBy, Pageable pageable);

}