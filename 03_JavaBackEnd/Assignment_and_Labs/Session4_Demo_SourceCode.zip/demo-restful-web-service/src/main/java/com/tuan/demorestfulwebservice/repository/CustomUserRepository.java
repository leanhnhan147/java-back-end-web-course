package com.tuan.demorestfulwebservice.repository;

import com.tuan.demorestfulwebservice.model.User;

import java.util.List;

public interface CustomUserRepository {
    List<User> findUserByNameUsingCriteria(String name);
}
