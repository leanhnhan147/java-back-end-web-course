package com.tuan.demorestfulwebservice.controller;

import com.tuan.demorestfulwebservice.model.Course;
import com.tuan.demorestfulwebservice.model.User;
import com.tuan.demorestfulwebservice.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/manytomany")
public class ManyToManyDemo {

    @Autowired
    private UserRepository userRepository;

    @PostMapping
    public void addCoursesForUser() {
        User user = new User();
        user.setName("Nguyen Van A");

        List<Course> courses = new ArrayList<>();
        Course firstCourse = new Course();
        firstCourse.setName("Course C");
        Course secondCourse = new Course();
        secondCourse.setName("Course D");
        courses.add(firstCourse);
        courses.add(secondCourse);


        user.setCourses(courses);
        userRepository.save(user);
    }
}
