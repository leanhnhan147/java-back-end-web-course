package com.tuan.demorestfulwebservice.repository;

import com.tuan.demorestfulwebservice.model.Instructor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InstructorRepository extends JpaRepository<Instructor, Long> {
}
