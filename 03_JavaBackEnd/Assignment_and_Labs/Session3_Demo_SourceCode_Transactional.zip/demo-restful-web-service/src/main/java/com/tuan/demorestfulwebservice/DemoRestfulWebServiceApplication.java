package com.tuan.demorestfulwebservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoRestfulWebServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoRestfulWebServiceApplication.class, args);
    }

}
