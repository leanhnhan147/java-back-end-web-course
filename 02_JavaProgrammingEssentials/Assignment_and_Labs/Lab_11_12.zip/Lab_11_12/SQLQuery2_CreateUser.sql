CREATE LOGIN qlhocvien WITH PASSWORD = '123'
GO
use QLHocVien;
Go
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'qlhocvien')
BEGIN
    CREATE USER qlhocvien FOR LOGIN qlhocvien;
    EXEC sp_addrolemember N'db_owner', N'qlhocvien'
    EXEC master..sp_addsrvrolemember @loginame = N'qlhocvien', @rolename = N'sysadmin'
END;
GO