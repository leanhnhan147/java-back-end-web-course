package myconnection;

import java.sql.Connection;
import java.sql.DriverManager;

public class MyMSSQLServerConnection {
	public static Connection getConnection() {
		Connection con = null;
		try {
			String connectionUrl = "jdbc:sqlserver://DESKTOP-7BK455O:1433;databaseName=QLHocVien;user=qlhocvien;password=123";
			con = DriverManager.getConnection(connectionUrl);
		} catch (Exception e) {
			System.out.println(e);
			return null;
		}
		return con;
	}
}
