package main;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import myconnection.MySQLConnection;

public class TestConnection {

	public static void main(String[] args) {
		Connection con = MySQLConnection.getConnection();
		if (con == null) {
			System.out.println("Cannot connect to the MySQL Database Server!");
		} else {
			System.out.println("Connection to MySQL...");
			try {
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery("select * from users");
				while (rs.next())
					System.out.println(rs.getInt(1) + "  " + rs.getString(2) + "  " + rs.getString(3)
									+ " " + rs.getString(4));
				con.close();
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			
		}
	}

}
