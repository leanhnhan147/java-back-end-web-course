package main;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import myconnection.MyMSSQLServerConnection;

public class TestMSSQLConnection {

	public static void main(String[] args) {
		Connection con = MyMSSQLServerConnection.getConnection();
		if (con == null) {
			System.out.println("Cannot connect to the MSSQL Database Server!");
		} else {
			System.out.println("Connection to MSSQL...");
			try {
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery("select * from dbo.hocvien");
				while (rs.next())
					System.out.println(rs.getInt(1) + "  " + rs.getString(2) + "  " + rs.getString(3)
									+ " " + rs.getString(4));
				con.close();
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			
		}
	}

}
