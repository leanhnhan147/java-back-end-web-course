package jdbc;

import java.sql.*;

public class GetCountForDepartment {
	public static void main(String[] args) throws SQLException {
		Connection myConn = null;
		CallableStatement myStm = null;
		
		String url = "jdbc:mysql://localhost:3306/jdbcdemo";
		String user = "student";
		String pwd = "student";
		
		String department = "Engineering";
		
		myConn = DriverManager.getConnection(url, user, pwd);
		
		myStm = myConn.prepareCall("{call jdbcdemo.get_count_for_department(?,?)}");
		
		myStm.setString(1, department);
		myStm.registerOutParameter(2, Types.DOUBLE);
		
		myStm.execute();
		
		double count = myStm.getDouble(2);
		
		System.out.println("The number employee of " + department + " is " + count);
		
		
		myStm.setString(1, "HR");
		myStm.registerOutParameter(2, Types.DOUBLE);
		
		myStm.execute();
		
		count = myStm.getDouble(2);
		
		System.out.println("The number employee of " + "HR" + " is " + count);
	}

}
