package jdbc;

import java.sql.*;

public class IncreaseSlalaries {

	public static void main(String[] args) throws SQLException {
		Connection myConn = null;
		CallableStatement myStm = null;
		
		String url = "jdbc:mysql://localhost:3306/jdbcdemo";
		String user = "student";
		String pwd = "student";
		
		String department = "Engineering";
		double increseSalary = 10000;
		
		// 1. create connection
		myConn = DriverManager.getConnection(url, user, pwd);
		
		// 2. prepare callable statement
		myStm = myConn.prepareCall("{call jdbcdemo.increase_salaries_for_department(?, ?)}");
		
		// 3. set data for procedure
		myStm.setString(1, department);
		myStm.setDouble(2, increseSalary);
		
		System.out.println("BEFORE INCREASE SALARY");
		showSalaries(myConn, department);
		
		myStm.execute();
		System.out.println("EXECUTE Store procedure successful \n");
		
		System.out.println("AFTER INCREASE SALARY");
		System.out.println("Salary of employee in " + department + "\n");
		showSalaries(myConn, department);
		
		
		if(myStm != null) {
			myStm.close();
		}
		
		if(myConn != null) {
			myConn.close();
		}
	}
	
	private static void showSalaries(Connection conn, String department) throws SQLException {
		PreparedStatement preStm = null;
		ResultSet myRs = null;
		
		preStm = conn.prepareStatement("select * from employees where department=?");
		preStm.setString(1, department);
		
		myRs = preStm.executeQuery();
		while(myRs.next()) {
			String lastName = myRs.getString("last_name");
			String firstName = myRs.getString("first_name");
			double salary = myRs.getDouble("salary");
			String depart = myRs.getString("department");
			
			System.out.println(lastName + " " + firstName + " " + salary + " " + department);
		}
		
		
	}
}
